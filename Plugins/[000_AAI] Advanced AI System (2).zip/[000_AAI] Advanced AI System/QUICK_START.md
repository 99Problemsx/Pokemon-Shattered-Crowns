# Advanced AI System - Quick Start Guide

## 🚀 5-Minute Setup

### Step 1: Install
1. Extract `[000_AAI] Advanced AI System` folder to `Plugins/`
2. Your structure should look like:
   ```
   Plugins/
     [000_AAI] Advanced AI System/
       1_Core/
       2_Move_Intelligence/
       ...
       README.md
   ```

### Step 2: Configure (Optional)
Edit `Plugins/[000_AAI] Advanced AI System/1_Core/[001] Settings.rb`:
```ruby
ENABLE_WILD_POKEMON_AI = true
WILD_POKEMON_SKILL_LEVEL = 85
SHOW_MOVE_EXPLANATIONS = true
DEBUG_MODE = false
```
*Skip this to use defaults (wild AI at level 100, explanations ON)*

### Step 3: Launch & Test
1. Start your game
2. Battle any trainer with skill ≥ 70 or any wild Pokemon
3. Watch for move explanations: `"Thunder Wave (Paralyze fast threat)"`
4. Press **F9** to open debug menu

---

## ⚡ Quick Tips

### Adjust Difficulty
**Too Easy?**
- Edit Settings.rb: `WILD_POKEMON_SKILL_LEVEL = 100`
- Set trainer skills to 85-100 in PBS/trainers.txt

**Too Hard?**
- Edit Settings.rb: `WILD_POKEMON_SKILL_LEVEL = 50`
- Lower trainer skills in PBS/trainers.txt

### Test Features
Press **F9** → "Change AI Skill Level"
- **50** = Basic (move scoring only)
- **70** = Advanced (setup detection, predictions)
- **85** = Expert (items, patterns, personalities)
- **100** = Master (all features)

### Debug Issues
1. Edit Settings.rb: `DEBUG_MODE = true`
2. Check console for errors
3. Look for "Advanced AI System loaded" message
4. Press F9 → "Show AI Stats" to verify it's working

### Disable Features
Don't want certain systems? Edit Settings.rb:
```ruby
# In the SKILL_THRESHOLDS section, set high values:
:prediction => 999  # Disables predictions
:items => 999       # Disables item intelligence
```

---

## 🎯 Common Use Cases

### "I want wild Pokemon to be challenging but fair"
Edit Settings.rb:
```ruby
WILD_POKEMON_SKILL_LEVEL = 70
```

### "I want to see what the AI is thinking"
Edit Settings.rb:
```ruby
SHOW_MOVE_EXPLANATIONS = true
DEBUG_MODE = true
LOG_TO_CONSOLE = true
```

### "I just want it to work with defaults"
Don't edit Settings.rb - defaults are ready to go!

### "I want to test a specific AI level quickly"
1. Start battle
2. Press **F9**
3. "Change AI Skill Level" → 85
4. Battle continues with new difficulty

---

## 📊 Understanding Skill Levels

| Level | What It Means |
|-------|---------------|
| 0-49 | Random moves (vanilla) |
| 50 | Basic move scoring, type effectiveness |
| 60 | + Hazard awareness, setup recognition |
| 70 | + Switch intelligence, prediction |
| 85 | + Item intelligence, pattern learning |
| 100 | + Terastallization (if DBK_006 installed) |

**Recommendation:** 
- Early game trainers: 50-60
- Mid game: 70-80
- Gym Leaders: 85
- Elite Four / Champion: 90-100
- Wild Pokemon: 70-85

---

## 🔧 Troubleshooting

### "AI still uses random moves"
✅ Check trainer skill in PBS/trainers.txt (must be ≥ 50)  
✅ Verify `ENABLED = true` in Settings.rb  
✅ Check console for errors (`DEBUG_MODE = true`)

### "No move explanations showing"
✅ Set `SHOW_MOVE_EXPLANATIONS = true` in Settings.rb  
✅ Only shows for **opponent** Pokemon, not yours  
✅ Restart game after changing Settings.rb

### "F9 menu doesn't open"
✅ Must be in $DEBUG mode OR have `DebugMode = true`  
✅ Press F9 during your turn (command selection)  
✅ Check if Input::F9 is mapped in your Essentials version

### "Plugin not loading"
✅ Check folder name: `[000_AAI] Advanced AI System`  
✅ Verify `meta.txt` exists in plugin folder  
✅ Look for load errors in console  
✅ Make sure no duplicate AI plugins installed

---

## 🎮 Next Steps

- Read [README.md](README.md) for full feature list
- Check [CHANGELOG.md](CHANGELOG.md) for version history
- Experiment with F9 debug menu
- Adjust `PBS/ai_config.txt` to your preference
- Test different skill levels to find your ideal balance

**Enjoy competitive AI battles! 🎉**
