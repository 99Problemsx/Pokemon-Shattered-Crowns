#===============================================================================
# Advanced AI System - Move Scorer
# Intelligent Move Scoring with 20+ Factors
#===============================================================================

class Battle::AI
  #-----------------------------------------------------------------------------
  # Base method for AI move registration - provides hook point for all AI extensions
  # This is the foundation method that other AI files will alias to add their logic
  #-----------------------------------------------------------------------------
  def pbRegisterMove(user, move)
    return 0 unless move && user
    # Base scoring - delegates to the comprehensive move scorer
    # Choose first valid opponent as target (will be refined by score_move_advanced)
    target = @battle.allOtherSideBattlers(user.index).find { |b| b && !b.fainted? }
    return 0 unless target
    score_move_advanced(move, user, target, @battle.pbGetOwnerFromBattlerIndex(user.index))
  end

  # Enhanced Move Scoring Logic
  def score_move_advanced(move, user, target, skill)
    return 0 unless move && user && target
    
    # === CRITICAL SELF-AWARENESS CHECKS ===
    # These return -1000 for moves that WILL FAIL due to our own status
    
    # Choice Lock: If we're locked, only the locked move can be used
    if user.effects[PBEffects::ChoiceBand] && user.effects[PBEffects::ChoiceBand] != move.id
      return -1000  # Can't use any other move when Choice-locked
    end
    
    # Encore: Must use the encored move
    if user.effects[PBEffects::Encore] > 0 && user.effects[PBEffects::EncoreMove]
      return -1000 if move.id != user.effects[PBEffects::EncoreMove]
    end
    
    # Disable: Can't use the disabled move
    if user.effects[PBEffects::Disable] > 0 && user.effects[PBEffects::DisableMove]
      return -1000 if move.id == user.effects[PBEffects::DisableMove]
    end
    
    # Taunt: Can't use status moves
    if user.effects[PBEffects::Taunt] > 0 && move.statusMove?
      return -1000
    end
    
    # Heal Block: Can't use healing moves
    if user.effects[PBEffects::HealBlock] > 0
      healing_moves = [:RECOVER, :SOFTBOILED, :ROOST, :SLACKOFF, :MOONLIGHT, :MORNINGSUN, 
                       :SYNTHESIS, :WISH, :SHOREUP, :LIFEDEW, :JUNGLEHEALING, :LUNARBLESSING]
      return -1000 if healing_moves.include?(move.id)
    end
    
    # Imprison: Can't use moves the opponent has imprisoned
    @battle.allOtherSideBattlers(user.index).each do |opp|
      next unless opp && !opp.fainted?
      if opp.effects[PBEffects::Imprison]
        opp.moves.each do |opp_move|
          return -1000 if opp_move && opp_move.id == move.id
        end
      end
    end
    
    # === CRITICAL: FALSE SWIPE IN PVP ===
    # FALSE SWIPE should NEVER be used against trainers/PVP
    if move.id == :FALSESWIPE && !@battle.wildBattle?
      return -999  # Terrible in PVP
    end
    
    # Torment: Can't use the same move twice in a row
    if user.effects[PBEffects::Torment] && user.battler.lastMoveUsed == move.id
      return -1000
    end
    
    # Fake Out / First Impression: Only work on first turn out
    if [:FAKEOUT, :FIRSTIMPRESSION].include?(move.id) && user.turnCount > 0
      return -1000  # These moves fail after turn 1
    end
    
    # Throat Chop: Can't use sound moves
    if user.effects[PBEffects::ThroatChop] > 0 && move.soundMove?
      return -1000
    end
    
    # Gravity: Can't use airborne moves
    if @battle.field.effects[PBEffects::Gravity] > 0
      gravity_blocked = [:FLY, :BOUNCE, :SKYDROP, :MAGNETRISE, :TELEKINESIS, :HIGHJUMPKICK, :JUMPKICK, :FLYINGPRESS]
      return -1000 if gravity_blocked.include?(move.id)
    end
    
    # Prankster vs Dark type: Status moves fail
    if AdvancedAI::Utilities.prankster_blocked?(user, target, move)
      return -1000  # Prankster status move blocked by Dark type
    end
    
    # === MOVE-SPECIFIC FAILURE CHECKS ===
    
    # Status-inflicting moves: Don't use if target already has a status condition
    status_moves = {
      :THUNDERWAVE => :PARALYSIS,
      :STUNSPORE => :PARALYSIS,
      :GLARE => :PARALYSIS,
      :NUZZLE => :PARALYSIS,
      :ZAPCANNON => :PARALYSIS,
      :BODYSLAM => :PARALYSIS,  # 30% chance but still counts
      :TOXIC => :POISON,
      :POISONPOWDER => :POISON,
      :POISONGAS => :POISON,
      :POISONFANG => :POISON,
      :TOXICSPIKES => :POISON,  # On grounded targets
      :WILLOWISP => :BURN,
      :SCALD => :BURN,
      :FLAREBLITZ => :BURN,
      :SACREDFIRE => :BURN,
      :SLEEPPOWDER => :SLEEP,
      :SPORE => :SLEEP,
      :HYPNOSIS => :SLEEP,
      :DARKVOID => :SLEEP,
      :GRASSWHISTLE => :SLEEP,
      :LOVELYKISS => :SLEEP,
      :SING => :SLEEP
    }
    
    if status_moves.key?(move.id)
      # Target already has ANY status condition
      if target.status != :NONE
        AdvancedAI.log("#{move.name} blocked: #{target.name} already has #{target.status}", "StatusSpam")
        return -1000  # Can't inflict status on already-statused Pokemon
      end
      
      # Safeguard protection
      if target.pbOwnSide.effects[PBEffects::Safeguard] > 0
        AdvancedAI.log("#{move.name} blocked: Safeguard active on #{target.name}'s side", "StatusSpam")
        return -1000  # Safeguard blocks status
      end
      
      # Misty Terrain blocks status (for grounded targets)
      if @battle.field.terrain == :Misty
        if !target.airborne? && !target.hasActiveAbility?(:LEVITATE)
          AdvancedAI.log("#{move.name} blocked: #{target.name} protected by Misty Terrain", "StatusSpam")
          return -1000  # Misty Terrain prevents status for grounded
        end
      end
    end
    
    # Leech Seed: Can't use on already seeded targets or Grass types
    if move.id == :LEECHSEED
      if target.effects[PBEffects::LeechSeed] >= 0
        AdvancedAI.log("Leech Seed blocked: #{target.name} already seeded", "RedundantMove")
        return -1000
      end
      return -1000 if target.pbHasType?(:GRASS)  # Grass types are immune
    end
    
    # Substitute: Don't use if we already have a substitute
    if move.id == :SUBSTITUTE
      if user.effects[PBEffects::Substitute] > 0
        AdvancedAI.log("Substitute blocked: #{user.name} already has Substitute", "RedundantMove")
        return -1000
      end
    end
    
    # Yawn: Don't use if target is already drowsy or asleep
    if move.id == :YAWN
      if target.effects[PBEffects::Yawn] > 0
        AdvancedAI.log("Yawn blocked: #{target.name} already drowsy", "RedundantMove")
        return -1000
      end
      if target.status == :SLEEP
        AdvancedAI.log("Yawn blocked: #{target.name} already asleep", "RedundantMove")
        return -1000
      end
    end
    
    # Taunt: Don't use if target is already taunted
    if move.id == :TAUNT
      if target.effects[PBEffects::Taunt] > 0
        AdvancedAI.log("Taunt blocked: #{target.name} already taunted", "RedundantMove")
        return -1000
      end
    end
    
    # Encore: Don't use if target is already encored
    if move.id == :ENCORE
      if target.effects[PBEffects::Encore] > 0
        AdvancedAI.log("Encore blocked: #{target.name} already encored", "RedundantMove")
        return -1000
      end
    end
    
    # Embargo: Don't use if target is already embargoed
    if move.id == :EMBARGO
      if target.effects[PBEffects::Embargo] > 0
        AdvancedAI.log("Embargo blocked: #{target.name} already embargoed", "RedundantMove")
        return -1000
      end
    end
    
    # Torment: Don't use if target is already tormented
    if move.id == :TORMENT
      if target.effects[PBEffects::Torment]
        AdvancedAI.log("Torment blocked: #{target.name} already tormented", "RedundantMove")
        return -1000
      end
    end
    
    # Ingrain: Don't use if we're already ingrained
    if move.id == :INGRAIN
      if user.effects[PBEffects::Ingrain]
        AdvancedAI.log("Ingrain blocked: #{user.name} already ingrained", "RedundantMove")
        return -1000
      end
    end
    
    # Aqua Ring: Don't use if we already have Aqua Ring
    if move.id == :AQUARING
      if user.effects[PBEffects::AquaRing]
        AdvancedAI.log("Aqua Ring blocked: #{user.name} already has Aqua Ring", "RedundantMove")
        return -1000
      end
    end
    
    # Screens: Don't use if already active on our side
    if move.id == :REFLECT
      if user.pbOwnSide.effects[PBEffects::Reflect] > 0
        AdvancedAI.log("Reflect blocked: already active", "ScreenSpam")
        return -1000
      end
    end
    
    if move.id == :LIGHTSCREEN
      if user.pbOwnSide.effects[PBEffects::LightScreen] > 0
        AdvancedAI.log("Light Screen blocked: already active", "ScreenSpam")
        return -1000
      end
    end
    
    if move.id == :AURORAVEIL
      if user.pbOwnSide.effects[PBEffects::AuroraVeil] > 0
        AdvancedAI.log("Aurora Veil blocked: already active", "ScreenSpam")
        return -1000
      end
    end
    
    # Hazards: Don't set if already at maximum layers
    if move.id == :STEALTHROCK
      if target.pbOwnSide.effects[PBEffects::StealthRock]
        AdvancedAI.log("Stealth Rock blocked: already active on opponent's side", "HazardSpam")
        return -1000
      end
    end
    
    if move.id == :SPIKES
      spikes_count = target.pbOwnSide.effects[PBEffects::Spikes]
      if spikes_count >= 3
        AdvancedAI.log("Spikes blocked: max 3 layers already active", "HazardSpam")
        return -1000  # Max 3 layers
      end
    end
    
    if move.id == :TOXICSPIKES
      toxic_spikes_count = target.pbOwnSide.effects[PBEffects::ToxicSpikes]
      if toxic_spikes_count >= 2
        AdvancedAI.log("Toxic Spikes blocked: max 2 layers already active", "HazardSpam")
        return -1000  # Max 2 layers
      end
    end
    
    if move.id == :STICKYWEB
      if target.pbOwnSide.effects[PBEffects::StickyWeb]
        AdvancedAI.log("Sticky Web blocked: already active on opponent's side", "HazardSpam")
        return -1000
      end
    end
    
    # Tailwind: Don't use if already active
    if move.id == :TAILWIND
      if user.pbOwnSide.effects[PBEffects::Tailwind] > 0
        AdvancedAI.log("Tailwind blocked: already active", "FieldSpam")
        return -1000
      end
    end
    
    # Trick Room: Don't use if already active (unless intentionally turning it off)
    if move.id == :TRICKROOM
      # Only penalty if we WANT Trick Room and it's already up
      # (Advanced users might want to turn it off, so this is skill-dependent)
      if @battle.field.effects[PBEffects::TrickRoom] > 0 && skill < 80
        AdvancedAI.log("Trick Room blocked: already active (low skill AI)", "FieldSpam")
        return -1000  # Low skill AI won't understand toggling
      end
    end
    
    # Wish: Don't use if we already have Wish coming
    if move.id == :WISH
      return -1000 if user.effects[PBEffects::Wish] > 0
    end
    
    base_score = 100  # Neutral Start
    
    # === TYPE-ABSORBING ABILITY CHECK ===
    # Don't attack into Water Absorb, Volt Absorb, Flash Fire, Sap Sipper, etc.
    if move.damagingMove?
      absorption_penalty = AdvancedAI::Utilities.score_type_absorption_penalty(user, target, move)
      if absorption_penalty < -100
        return absorption_penalty  # Heavy penalty - avoid this move
      end
      base_score += absorption_penalty
      
      # Bulletproof immunity
      if AdvancedAI::Utilities.bulletproof_immune?(user, target, move)
        return -200  # Ball/bomb move blocked
      end
      
      # Soundproof immunity
      if AdvancedAI::Utilities.soundproof_immune?(user, target, move)
        return -200  # Sound move blocked
      end
    end
    
    # === DAMAGE ANALYSIS ===
    if move.damagingMove?
      base_score += score_damage_potential(move, user, target, skill)
      base_score += score_type_effectiveness(move, user, target)
      base_score += score_stab_bonus(move, user)
      base_score += score_crit_potential(move, user, target)
      
      # Contact Punishment (Rough Skin, Iron Barbs, Rocky Helmet)
      if move.contactMove?
        base_score -= score_contact_punishment(move, user, target)
      end
    end
    
    # === STATUS ANALYSIS ===
    if move.statusMove?
      base_score += score_status_utility(move, user, target, skill)
    end
    
    # === SETUP ANALYSIS ===
    if move.function_code.start_with?("RaiseUser") || AdvancedAI.setup_move?(move.id)
      base_score += score_setup_value(move, user, target, skill)
      base_score += score_setup_vs_mirror_herb(move, user, target)
    end
    
    # === SITUATIONAL FACTORS ===
    base_score += score_priority(move, user, target)
    base_score += score_accuracy(move, skill)
    base_score += score_recoil_risk(move, user)
    base_score += score_secondary_effects(move, user, target)
    base_score += score_moody_pressure(move, user, target)
    base_score += score_status_vs_berry(move, user, target)
    
    # === NEW: REPORTED ISSUES HANDLING ===
    base_score += score_protect_utility(move, user, target)
    base_score += score_prankster_bonus(move, user)
    base_score += score_pivot_utility(move, user, target, skill)
    
    # === MOVE REPETITION PENALTY ===
    base_score += score_move_repetition_penalty(move, user)
    
    # === ADVANCED SITUATIONAL AWARENESS ===
    base_score += score_destiny_bond_awareness(move, user, target)
    base_score += score_sucker_punch_risk(move, user, target, skill)
    base_score += score_forced_switch_items(move, user, target)
    base_score += score_item_disruption(move, user, target)
    
    # === GLAIVE RUSH SELF-RISK ===
    # If using Glaive Rush, AI takes 2x damage next turn - factor this risk
    if move.id == :GLAIVERUSH
      # Estimate incoming damage if we survive
      expected_retaliation = estimate_incoming_damage(user, target)
      doubled_damage = expected_retaliation * 2
      
      if doubled_damage >= user.hp
        base_score -= 80  # High chance of dying next turn
      elsif doubled_damage >= user.hp * 0.7
        base_score -= 40  # Significant risk
      elsif doubled_damage >= user.hp * 0.4
        base_score -= 20  # Moderate risk
      else
        base_score -= 5   # Minor risk
      end
      
      # But if this will KO the target, the risk doesn't matter
      rough_damage = calculate_rough_damage(move, user, target)
      if rough_damage >= target.hp
        base_score += 50  # KO negates the drawback
      end
    end
    
    return base_score
  end
  
  private
  
  # Damage Potential
  def score_damage_potential(move, user, target, skill)
    score = 0
    
    # Effective Base Power (Factors in Multi-Hits, Skill Link, etc.)
    bp = calculate_effective_power(move, user, target)
    
    # Base Power Bonus
    score += (bp / 10.0) if bp > 0
    
    # KO Potential
    if skill >= 60
      # Use effective BP for damage calc
      rough_damage = calculate_rough_damage(move, user, target, bp)
      if rough_damage >= target.hp
        score += 100  # Guaranteed KO
      elsif rough_damage >= target.hp * 0.7
        score += 50   # Likely KO
      elsif rough_damage >= target.hp * 0.4
        score += 25
      end
    end
    
    # Multi-Target Bonus
    score += 30 if move.pbTarget(user).num_targets > 1 && @battle.pbSideSize(0) > 1
    
    return score
  end
  
  # Type Effectiveness
  def score_type_effectiveness(move, user, target)
    type_mod = Effectiveness.calculate(move.type, target.types[0], target.types[1])
    
    if Effectiveness.super_effective?(type_mod)
      return 40
    elsif Effectiveness.not_very_effective?(type_mod)
      return -30
    elsif Effectiveness.ineffective?(type_mod)
      return -200
    end
    
    return 0
  end
  
  # STAB Bonus
  def score_stab_bonus(move, user)
    return 20 if user.pbHasType?(move.type)
    return 0
  end
  
  # Critical Hit Potential
  def score_crit_potential(move, user, target)
    score = 0
    
    # 1. Critical Immunity Check
    # If target has Battle Armor, Shell Armor, or Lucky Chant, crits are impossible/unlikely
    return 0 if target.hasActiveAbility?(:BATTLEARMOR) || target.hasActiveAbility?(:SHELLARMOR)
    return 0 if target.pbOwnSide.effects[PBEffects::LuckyChant] > 0
    
    # Check for High Crit Rate Move
    is_high_crit = (move.function_code == "HighCriticalHitRate")
    is_always_crit = move.function_code.include?("AlwaysCriticalHit")
    
    # 2. Synergy: Focus Energy + High Crit Move
    # Focus Energy (+2 stages) + High Crit Move (+1 stage) = +3 stages (100% Crit)
    # NOTE: Do NOT give a synergy bonus for AlwaysCriticalHit moves, because Focus Energy
    # adds nothing to them (they already crit).
    if user.effects[PBEffects::FocusEnergy] > 0
      if is_high_crit
        score += 50  # Massive bonus for correctly using the combo
      elsif !is_always_crit
        # Focus Energy alone gives 50% crit rate (Stage 2)
        # Still good for normal moves, but useless for AlwaysCrit moves
        score += 20
      end
    elsif is_high_crit
      # High Crit Move alone is 1/8 chance (Stage 1), decent but not reliable
      score += 15
    end
    
    # 3. Ignore Stat Changes
    # Critical hits ignore the target's positive defense stages...
    ignore_target_def = (target.stages[:DEFENSE] > 0 && move.physicalMove?) || 
                        (target.stages[:SPECIAL_DEFENSE] > 0 && move.specialMove?)
    
    # ...AND they ignore the user's negative attack stages!
    ignore_user_debuff = (user.stages[:ATTACK] < 0 && move.physicalMove?) || 
                         (user.stages[:SPECIAL_ATTACK] < 0 && move.specialMove?)
    
    if ignore_target_def || ignore_user_debuff
      # Only apply this bonus if we have a RELIABLE crit chance
      # (Focus Energy active OR Move always crits)
      if user.effects[PBEffects::FocusEnergy] > 0 || move.function_code.include?("AlwaysCriticalHit")
        score += 30 # Value bypassing the stats
      end
    end
    
    return score
  end
  
  # Status Move Utility
  def score_status_utility(move, user, target, skill)
    score = 0
    
    # Determine opponent side (for hazards)
    opponent_side = @battle.pbOwnedByPlayer?(target.index) ? @battle.sides[1] : @battle.sides[0]
    
    case move.function_code
    # Hazards
    when "AddSpikesToFoeSide"
      score += 60 if opponent_side.effects[PBEffects::Spikes] < 3
    when "AddStealthRocksToFoeSide"
      unless opponent_side.effects[PBEffects::StealthRock]
        score += 80
        # High priority early game or if healthy
        score += 40 if @battle.turnCount <= 2 || user.hp > user.totalhp * 0.8
      end
    when "AddToxicSpikesToFoeSide"
      score += 50 if opponent_side.effects[PBEffects::ToxicSpikes] < 2
    when "AddStickyWebToFoeSide"
      # Score high if opponent side has no sticky web and we aren't faster
      score += 60 unless opponent_side.effects[PBEffects::StickyWeb]
    # Screens
    when "StartWeakenPhysicalDamageAgainstUserSide" # Reflect
      if user.pbOwnSide.effects[PBEffects::Reflect] == 0
        score += 50 
        # Bonus if opponent's last move was Physical
        if target.lastRegularMoveUsed
          move_data = GameData::Move.try_get(target.lastRegularMoveUsed)
          score += 40 if move_data&.physical?
        end
      end
    when "StartWeakenSpecialDamageAgainstUserSide" # Light Screen
      if user.pbOwnSide.effects[PBEffects::LightScreen] == 0
        score += 50
        # Bonus if opponent's last move was Special
        if target.lastRegularMoveUsed
          move_data = GameData::Move.try_get(target.lastRegularMoveUsed)
          score += 40 if move_data&.special?
        end
      end
    when "StartWeakenDamageAgainstUserSideIfHail" # Aurora Veil
      if (@battle.pbWeather == :Hail || @battle.pbWeather == :Snow) && user.pbOwnSide.effects[PBEffects::AuroraVeil] == 0
        score += 60
        # Bonus if opponent's last move was Damaging
        if target.lastRegularMoveUsed
          move_data = GameData::Move.try_get(target.lastRegularMoveUsed)
          score += 40 if move_data&.damaging?
        end
      end
      
    # Recovery
    when "HealUserHalfOfTotalHP", "HealUserDependingOnWeather"
      hp_percent = user.hp.to_f / user.totalhp
      score += 80 if hp_percent < 0.3
      score += 50 if hp_percent < 0.5
      score += 20 if hp_percent < 0.7
      
    # Status Infliction
    when "ParalyzeTarget"
      # Thunder Wave - CRITICAL vs faster targets
      if target.pbSpeed > user.pbSpeed && target.status == :NONE
        score += 80  # Massive bonus - cripple faster threats
        # Extra bonus if we can KO after paralyze
        target_speed_after = target.pbSpeed / 2
        if user.pbSpeed > target_speed_after
          score += 30  # Now we outspeed and can KO
        end
      elsif target.status == :NONE
        score += 25  # Still useful vs slower targets
      end
      
    when "BurnTarget"
      # Will-O-Wisp - CRITICAL vs physical attackers
      if target.attack > target.spatk && target.status == :NONE
        score += 100  # Massive bonus - nerf physical attackers
        # Extra bonus if we resist their attacks
        if target.lastRegularMoveUsed
          last_move = GameData::Move.try_get(target.lastRegularMoveUsed)
          if last_move && last_move.physicalMove?
            score += 40  # They're locked into physical damage
          end
        end
      elsif target.status == :NONE
        score += 30  # Still useful for passive damage
      end
      
    when "PoisonTarget"
      # Basic Poison - good chip damage
      if target.status == :NONE && target.hp > target.totalhp * 0.7
        score += 35
        # Bonus vs bulky targets
        if target.defense + target.spdef > 200
          score += 25  # Walls hate poison
        end
      end
      
    when "BadPoisonTarget"
      # Toxic - CRITICAL vs walls and stall
      if target.status == :NONE
        score += 60  # Strong base value
        # HUGE bonus vs bulky/recovery Pokemon
        if target.defense + target.spdef > 200
          score += 70  # Toxic destroys walls
        end
        # Bonus vs regenerator/recovery moves
        if target.hasActiveAbility?(:REGENERATOR)
          score += 50  # Counter regenerator stalling
        end
        # Bonus if we have stall tactics (Protect, recovery)
        stall_moves = [:PROTECT, :DETECT, :RECOVER, :ROOST, :SOFTBOILED, :WISH, :REST]
        user_knows_stall = user.battler.moves.any? { |m| stall_moves.include?(m.id) }
        if user_knows_stall
          score += 40  # Can stall out Toxic damage
        end
      end
      
    when "SleepTarget"
      # Sleep - CRITICAL control move
      if target.status == :NONE
        score += 90  # Sleep is incredibly powerful
        # Bonus if we can setup during sleep
        setup_moves = user.battler.moves.any? { |m| AdvancedAI.setup_move?(m.id) }
        if setup_moves
          score += 60  # Free setup turns!
        end
        # Bonus vs offensive threats
        if target.attack > 120 || target.spatk > 120
          score += 40  # Neutralize sweepers
        end
      end
      
    # Stat Drops
    when "LowerTargetAttack1", "LowerTargetAttack2"
      score += 30 if target.attack > target.spatk
    when "LowerTargetSpeed1", "LowerTargetSpeed2"
      score += 35 if target.pbSpeed > user.pbSpeed
    when "LowerTargetDefense1", "LowerTargetDefense2"
      score += 25 if user.attack > user.spatk
    end
    
    return score
  end
  
  # Setup Value
  def score_setup_value(move, user, target, skill)
    return 0 unless skill >= 55
    score = 0
    
    # Safe to setup?
    safe_to_setup = is_safe_to_setup?(user, target)
    
    if safe_to_setup

      # Boost Strength
      total_boosts = 0
      
      # Try to get data from MoveCategories
      setup_data = AdvancedAI.get_setup_data(move.id)
      if setup_data
        total_boosts = setup_data[:stages] || 1
      elsif move.function_code.start_with?("RaiseUser")
        # Extract boost amount from function code (e.g., "RaiseUserAttack1" -> 1)
        total_boosts = move.function_code.scan(/\d+/).last.to_i
        total_boosts = 1 if total_boosts == 0 # Default to 1 if no number (e.g., "RaiseUserAllStats1")
      else
        total_boosts = 1
      end
      score += total_boosts * 20
      
      # Sweep Potential
      if user.hp > user.totalhp * 0.7
        score += 30
      end
    else
      score -= 40  # Dangerous to setup
    end
    
    return score
  end
  
  # Priority
  def score_priority(move, user, target)
    return 0 if move.priority <= 0
    
    score = move.priority * 15
    
    # 1. Desperation Logic: User Low HP & Slower
    if user.hp <= user.totalhp * 0.33 && target.pbSpeed > user.pbSpeed
      score += 40 
    end

    # 2. Priority Blockers
    if move.priority > 0
      # Psychic Terrain (blocks priority against grounded targets)
      if @battle.field.terrain == :Psychic && target.affectedByTerrain?
        return -100
      end
      
      # Ability Blockers (Dazzling, Queenly Majesty, Armor Tail)
      # These abilities block priority moves targeting the user
      blocking_abilities = [:DAZZLING, :QUEENLYMAJESTY, :ARMORTAIL]
      if blocking_abilities.include?(target.ability_id) && !user.hasMoldBreaker?
        return -100
      end
    end
    
    # Extra Bonus if slower
    score += 30 if target.pbSpeed > user.pbSpeed
    
    # Extra Bonus if KO possible
    if move.damagingMove?
      rough_damage = calculate_rough_damage(move, user, target)
      score += 40 if rough_damage >= target.hp
    end
    
    return score
  end
  
  # Accuracy
  def score_accuracy(move, skill)
    # Use raw accuracy to avoid AIMove#accuracy crash (needs battler which might be nil)
    # If move is AIMove (wrapper), get inner move. If regular Move, use it directly.
    accuracy = move.respond_to?(:move) ? move.move.accuracy : move.accuracy
    return 0 if accuracy == 0  # Never-miss moves
    
    if accuracy < 70
      return -40
    elsif accuracy < 85
      return -20
    elsif accuracy < 95
      return -10
    end
    
    return 0
  end
  
  # Recoil Risk
  def score_recoil_risk(move, user)
    return 0 unless move.recoilMove?
    
    hp_percent = user.hp.to_f / user.totalhp
    
    if hp_percent < 0.3
      return -50  # Dangerous at low HP
    elsif hp_percent < 0.5
      return -25
    else
      return -10  # Acceptable risk
    end
  end
  
  # Secondary Effects
  def score_secondary_effects(move, user, target)
    score = 0
    
    # Covert Cloak blocks secondary effects
    if AdvancedAI::Utilities.has_covert_cloak?(target)
      return 0  # No secondary effect value
    end
    
    # Shield Dust blocks secondary effects
    if target.ability_id == :SHIELDDUST
      return 0
    end
    
    # Flinch
    if move.flinchingMove?
      # Inner Focus / Scrappy / Own Tempo etc. prevent flinch
      unless [:INNERFOCUS, :OWNTEMPO, :OBLIVIOUS].include?(target.ability_id)
        score += 20 if user.pbSpeed > target.pbSpeed
      end
    end
    
    # Stat Drops on Target
    if move.function_code.start_with?("LowerTarget")
      # Clear Amulet / Clear Body / White Smoke prevent stat drops
      if AdvancedAI::Utilities.has_clear_amulet?(target)
        score -= 10  # Wasted effect
      elsif [:CLEARBODY, :WHITESMOKE, :FULLMETALBODY].include?(target.ability_id)
        score -= 10
      else
        score += 20
      end
    end
    
    # Status Chance
    if ["ParalyzeTarget", "BurnTarget", "PoisonTarget", "SleepTarget", "FreezeTarget"].any? {|code| move.function_code.include?(code)}
      score += move.addlEffect / 2
    end
    
    return score
  end
  
  # Contact Move Punishment
  # Accounts for Rough Skin, Iron Barbs, Rocky Helmet, etc.
  def score_contact_punishment(move, user, target)
    return 0 unless move && move.contactMove?
    return 0 unless target
    
    # Long Reach ignores contact entirely
    return 0 if user.hasActiveAbility?(:LONGREACH)
    
    # Protective Pads prevents contact damage
    return 0 if user.hasActiveItem?(:PROTECTIVEPADS)
    
    score_penalty = 0
    mold_breaker = AdvancedAI::Utilities.ignores_ability?(user)
    
    # === Damage Abilities ===
    unless mold_breaker
      # Rough Skin / Iron Barbs (1/8 max HP)
      if target.hasActiveAbility?(:ROUGHSKIN) || target.hasActiveAbility?(:IRONBARBS)
        recoil_damage = user.totalhp / 8
        hp_percent_lost = (recoil_damage * 100.0 / [user.hp, 1].max)
        
        if hp_percent_lost >= 100
          score_penalty += 80  # Would KO self
        elsif hp_percent_lost >= 50
          score_penalty += 40  # Major damage
        elsif hp_percent_lost >= 25
          score_penalty += 20
        else
          score_penalty += 10
        end
      end
      
      # === Status Abilities ===
      if user.status == :NONE
        # Flame Body (30% Burn)
        if target.hasActiveAbility?(:FLAMEBODY)
          # Physical attackers hurt more by burn
          if user.attack > user.spatk
            score_penalty += 25
          else
            score_penalty += 10
          end
        end
        
        # Static (30% Paralysis)
        if target.hasActiveAbility?(:STATIC)
          # Fast Pokemon hurt more by paralysis
          if user.pbSpeed >= 100
            score_penalty += 20
          else
            score_penalty += 8
          end
        end
        
        # Poison Point (30% Poison)
        if target.hasActiveAbility?(:POISONPOINT)
          score_penalty += 10
        end
        
        # Effect Spore (30% sleep/para/poison)
        if target.hasActiveAbility?(:EFFECTSPORE)
          # Safety Goggles protects
          score_penalty += 15 unless user.hasActiveItem?(:SAFETYGOGGLES)
        end
      end
      
      # === Speed Drop Abilities ===
      # Gooey / Tangling Hair (-1 Speed)
      if target.hasActiveAbility?(:GOOEY) || target.hasActiveAbility?(:TANGLINGHAIR)
        # Only matters if we care about speed
        if user.pbSpeed >= target.pbSpeed
          score_penalty += 15  # Could lose speed advantage
        else
          score_penalty += 5   # Already slower
        end
      end
      
      # === Special Abilities ===
      # Perish Body (both get Perish Song)
      if target.hasActiveAbility?(:PERISHBODY)
        score_penalty += 30 unless user.effects[PBEffects::PerishSong] > 0
      end
      
      # Mummy / Lingering Aroma (changes ability)
      if target.hasActiveAbility?(:MUMMY) || target.hasActiveAbility?(:LINGERINGAROMA)
        # Only penalize if user has a good ability
        good_abilities = [:HUGEPOWER, :PUREPOWER, :SPEEDBOOST, :PROTEAN, :LIBERO,
                          :WONDERGUARD, :MAGICGUARD, :MULTISCALE, :SHADOWSHIELD]
        score_penalty += 25 if good_abilities.include?(user.ability_id)
      end
      
      # Wandering Spirit (swaps abilities)
      if target.hasActiveAbility?(:WANDERINGSPIRIT)
        score_penalty += 15  # Usually undesirable
      end
    end
    
    # === Rocky Helmet (not an ability) ===
    if target.hasActiveItem?(:ROCKYHELMET)
      recoil_damage = user.totalhp / 6
      hp_percent_lost = (recoil_damage * 100.0 / [user.hp, 1].max)
      
      if hp_percent_lost >= 100
        score_penalty += 100  # Would KO self
      elsif hp_percent_lost >= 50
        score_penalty += 50
      elsif hp_percent_lost >= 25
        score_penalty += 25
      else
        score_penalty += 12
      end
    end
    
    return score_penalty
  end
  
  # === HELPER METHODS ===
  
  def calculate_rough_damage(move, user, target, override_bp = nil)
    return 0 unless move.damagingMove?
    
    # Very Simplified Damage Calculation
    bp = override_bp || move.power
    return 0 if bp == 0
    
    # === GEN 9 VARIABLE POWER MOVES ===
    # Last Respects - 50 + 50 per fainted ally
    if move.id == :LASTRESPECTS && @battle
      bp = AdvancedAI::Utilities.last_respects_power(@battle, user)
    end
    
    # Rage Fist - 50 + 50 per hit taken
    if move.id == :RAGEFIST
      bp = AdvancedAI::Utilities.rage_fist_power(user)
    end
    
    # Collision Course / Electro Drift - 1.33x if SE
    if AdvancedAI::Utilities.collision_move_boost?(move)
      type_check = Effectiveness.calculate(move.type, target.types[0], target.types[1])
      bp = (bp * 1.33).to_i if Effectiveness.super_effective?(type_check)
    end
    
    # === SPECIAL MOVE BASE POWER SCALING ===
    # Facade doubles when statused
    if move.id == :FACADE && user.status != :NONE
      bp *= 2
    end
    
    # Hex doubles vs statused target
    if move.id == :HEX && target.status != :NONE
      bp *= 2
    end
    
    # Venoshock doubles vs poisoned target
    if move.id == :VENOSHOCK && [:POISON, :TOXIC].include?(target.status)
      bp *= 2
    end
    
    # Brine doubles at <50% HP
    if move.id == :BRINE && target.hp < target.totalhp / 2
      bp *= 2
    end
    
    # Avalanche / Revenge double if hit first
    if [:AVALANCHE, :REVENGE].include?(move.id) && user.lastHPLost > 0
      bp *= 2
    end
    
    # Stored Power / Power Trip - 20 BP per positive stat stage
    if [:STOREDPOWER, :POWERTRIP].include?(move.id)
      stat_boosts = 0
      GameData::Stat.each_battle do |stat|
        stage = user.stages[stat.id] rescue 0
        stat_boosts += stage if stage > 0
      end
      bp = 20 + (20 * stat_boosts)
    end
    
    # Knock Off - 1.5x damage if target has item
    if move.id == :KNOCKOFF && target.item && target.item != :NONE
      bp = (bp * 1.5).to_i
    end
    
    # Acrobatics - 2x damage without item
    if move.id == :ACROBATICS && (!user.item || user.item == :NONE)
      bp *= 2
    end
    
    # Poltergeist - fails if no item
    if move.id == :POLTERGEIST && (!target.item || target.item == :NONE)
      return 0  # Move fails
    end
    
    # === STAT CALCULATION ===
    atk = move.physicalMove? ? user.attack : user.spatk
    defense = move.physicalMove? ? target.defense : target.spdef
    
    # === SPECIAL STAT-USING MOVES ===
    # Foul Play - uses target's Attack stat
    if move.id == :FOULPLAY
      atk = target.attack
    end
    
    # Body Press - uses user's Defense instead of Attack
    if move.id == :BODYPRESS
      atk = user.defense
    end
    
    # Psyshock / Psystrike / Secret Sword - special attack vs physical Defense
    if [:PSYSHOCK, :PSYSTRIKE, :SECRETSWORD].include?(move.id)
      defense = target.defense  # Use Defense instead of SpDef
    end
    
    # Photon Geyser / Light That Burns the Sky - uses higher attacking stat
    if [:PHOTONGEYSER, :LIGHTTHATBURNSTHESKY].include?(move.id)
      atk = [user.attack, user.spatk].max
    end
    
    # === FIXED DAMAGE MOVES (bypass normal calc) ===
    # Seismic Toss / Night Shade - level-based fixed damage
    if [:SEISMICTOSS, :NIGHTSHADE].include?(move.id)
      return user.level
    end
    
    # Super Fang / Nature's Madness - 50% current HP
    if [:SUPERFANG, :NATURESMADNESS].include?(move.id)
      return [target.hp / 2, 1].max
    end
    
    # Final Gambit - user's remaining HP
    if move.id == :FINALGAMBIT
      return user.hp
    end
    
    # Dragon Rage - fixed 40 damage
    if move.id == :DRAGONRAGE
      return 40
    end
    
    # Sonic Boom - fixed 20 damage
    if move.id == :SONICBOOM
      return 20
    end
    
    # Endeavor - reduce to user's HP
    if move.id == :ENDEAVOR
      return [target.hp - user.hp, 0].max
    end
    
    # === UNAWARE HANDLING ===
    # If target has Unaware, ignore user's offensive stat boosts
    if target.ability_id == :UNAWARE && !AdvancedAI::Utilities.ignores_ability?(user)
      # Use base stat instead of boosted stat
      if move.physicalMove?
        atk = user.pokemon.attack rescue user.attack
      else
        atk = user.pokemon.spatk rescue user.spatk
      end
    end
    
    # If user has Unaware, ignore target's defensive stat boosts
    if user.ability_id == :UNAWARE
      if move.physicalMove?
        defense = target.pokemon.defense rescue target.defense
      else
        defense = target.pokemon.spdef rescue target.spdef
      end
    end
    
    # === BURN PHYSICAL DAMAGE REDUCTION ===
    burn_mod = 1.0
    if user.status == :BURN && move.physicalMove?
      # Guts ignores burn penalty AND gets 1.5x boost
      if user.ability_id == :GUTS
        burn_mod = 1.5
      # Flare Boost for special moves (but this is physical so skip)
      else
        burn_mod = 0.5  # Burn halves physical damage
      end
    end
    
    # Guts boost for other statuses too
    if user.ability_id == :GUTS && user.status != :NONE && user.status != :BURN
      burn_mod = 1.5
    end
    
    # === TYPE EFFECTIVENESS ===
    type_mod = Effectiveness.calculate(move.type, target.types[0], target.types[1])
    stab = user.pbHasType?(move.type) ? 1.5 : 1.0
    
    # Adaptability STAB boost
    if user.ability_id == :ADAPTABILITY && user.pbHasType?(move.type)
      stab = 2.0
    end
    
    # === ABILITY DAMAGE MODIFIERS ===
    ability_mod = 1.0
    
    # Huge Power / Pure Power
    if [:HUGEPOWER, :PUREPOWER].include?(user.ability_id) && move.physicalMove?
      ability_mod *= 2.0
    end
    
    # Hustle (physical +50%, accuracy penalty handled elsewhere)
    if user.ability_id == :HUSTLE && move.physicalMove?
      ability_mod *= 1.5
    end
    
    # Gorilla Tactics (physical +50% but locked)
    if user.ability_id == :GORILLATACTICS && move.physicalMove?
      ability_mod *= 1.5
    end
    
    # Transistor (Electric +50%)
    if user.ability_id == :TRANSISTOR && move.type == :ELECTRIC
      ability_mod *= 1.5
    end
    
    # Dragons Maw (Dragon +50%)
    if user.ability_id == :DRAGONSMAW && move.type == :DRAGON
      ability_mod *= 1.5
    end
    
    # === ITEM DAMAGE MODIFIERS ===
    item_mod = 1.0
    
    if user.item_id == :LIFEORB
      item_mod *= 1.3
    elsif user.item_id == :CHOICEBAND && move.physicalMove?
      item_mod *= 1.5
    elsif user.item_id == :CHOICESPECS && move.specialMove?
      item_mod *= 1.5
    elsif user.item_id == :EXPERTBELT && Effectiveness.super_effective?(type_mod)
      item_mod *= 1.2
    end
    
    # Type-boosting items
    type_items = {
      :SILKSCARF => :NORMAL, :BLACKBELT => :FIGHTING, :SHARPBEAK => :FLYING,
      :POISONBARB => :POISON, :SOFTSAND => :GROUND, :HARDSTONE => :ROCK,
      :SILVERPOWDER => :BUG, :SPELLTAG => :GHOST, :METALCOAT => :STEEL,
      :CHARCOAL => :FIRE, :MYSTICWATER => :WATER, :MIRACLESEED => :GRASS,
      :MAGNET => :ELECTRIC, :TWISTEDSPOON => :PSYCHIC, :NEVERMELTICE => :ICE,
      :DRAGONFANG => :DRAGON, :BLACKGLASSES => :DARK, :FAIRYFEATHER => :FAIRY
    }
    if type_items.key?(user.item_id) && move.type == type_items[user.item_id]
      item_mod *= 1.2
    end
    
    # Plates
    plate_types = {
      :FISTPLATE => :FIGHTING, :SKYPLATE => :FLYING, :TOXICPLATE => :POISON,
      :EARTHPLATE => :GROUND, :STONEPLATE => :ROCK, :INSECTPLATE => :BUG,
      :SPOOKYPLATE => :GHOST, :IRONPLATE => :STEEL, :FLAMEPLATE => :FIRE,
      :SPLASHPLATE => :WATER, :MEADOWPLATE => :GRASS, :ZAPPLATE => :ELECTRIC,
      :MINDPLATE => :PSYCHIC, :ICICLEPLATE => :ICE, :DRACOPLATE => :DRAGON,
      :DREADPLATE => :DARK, :PIXIEPLATE => :FAIRY
    }
    if plate_types.key?(user.item_id) && move.type == plate_types[user.item_id]
      item_mod *= 1.2
    end
    
    # === TARGET STATE MODIFIERS ===
    target_mod = 1.0
    
    # Glaive Rush vulnerability (target takes 2x damage)
    if defined?(PBEffects::GlaiveRush) && target.effects[PBEffects::GlaiveRush] > 0
      target_mod *= 2.0
    end
    
    # Type-resist berries (halve SE damage)
    if AdvancedAI::Utilities.has_resist_berry?(target, move.type) && 
       Effectiveness.super_effective?(type_mod)
      target_mod *= 0.5
    end
    
    # Assault Vest (1.5x SpDef vs special moves)
    if target.item_id == :ASSAULTVEST && move.specialMove?
      # Already factored into spdef stat, but note for consideration
    end
    
    # === FINAL CALCULATION ===
    damage = ((2 * user.level / 5.0 + 2) * bp * atk / [defense, 1].max / 50 + 2)
    damage *= type_mod / Effectiveness::NORMAL_EFFECTIVE.to_f
    damage *= stab
    damage *= burn_mod
    damage *= ability_mod
    damage *= item_mod
    damage *= target_mod
    
    return [damage.to_i, 1].max
  end
  
  def is_safe_to_setup?(user, target)
    # HP Check
    return false if user.hp < user.totalhp * 0.5
    
    # Speed Check
    return false if target.pbSpeed > user.pbSpeed * 1.5
    
    # Type Matchup Check
    target.moves.each do |move|
      next unless move && move.damagingMove?
      type_mod = Effectiveness.calculate(move.type, user.types[0], user.types[1])
      return false if Effectiveness.super_effective?(type_mod)
    end
    
    return true
  end
  
  # Calculates effective base power including multi-hit factors
  def calculate_effective_power(move, user, target)
    bp = move.power
    return 0 if bp == 0
    
    # Always Critical Hit Logic (e.g. Flower Trick, Frost Breath)
    if move.function_code.include?("AlwaysCriticalHit")
      # Check immunity
      is_immune = target.hasActiveAbility?(:BATTLEARMOR) || 
                  target.hasActiveAbility?(:SHELLARMOR) ||
                  target.pbOwnSide.effects[PBEffects::LuckyChant] > 0
      
      unless is_immune
        bp = (bp * 1.5).to_i
      end
    end
    
    return bp unless move.multiHitMove? || move.function_code == "HitTwoTimes"
    
    if move.multiHitMove?
      if user.hasActiveAbility?(:SKILLLINK)
        return bp * 5
      elsif user.hasActiveItem?(:LOADEDDICE)
        return bp * 4 # Average 4-5 hits
      elsif move.pbNumHits(user, [target]) == 2 # Fixed 2-hit moves check
         return bp * 2
      else
         return bp * 3 # Average for 2-5 hit moves
      end
    elsif move.function_code == "HitTwoTimes"
       return bp * 2
    end
    
    return bp
  end
  
  #=============================================================================
  # Advanced Situational Awareness Methods
  #=============================================================================
  
  # Destiny Bond Awareness - don't KO if we die too
  def score_destiny_bond_awareness(move, user, target)
    return 0 unless move.damagingMove?
    return 0 unless target.effects[PBEffects::DestinyBond]
    
    # Would we KO them?
    rough_damage = calculate_rough_damage(move, user, target, move.power)
    return 0 if rough_damage < target.hp  # Won't trigger
    
    # We would trigger Destiny Bond!
    hp_percent = user.hp.to_f / user.totalhp
    
    if hp_percent <= 0.3
      return -100  # We're low HP, absolutely not worth dying
    elsif hp_percent <= 0.5
      return -60   # Risky trade
    else
      return -20   # We're healthy, might be worth the trade
    end
  end
  
  # Sucker Punch Risk - fails if target uses non-damaging move
  def score_sucker_punch_risk(move, user, target, skill)
    return 0 unless move.id == :SUCKERPUNCH
    return 0 unless skill >= 60
    
    score = 0
    
    # Count target's status moves
    status_move_count = target.moves.count { |m| m && m.statusMove? }
    total_moves = target.moves.count { |m| m }
    
    return 0 if total_moves == 0
    
    status_ratio = status_move_count.to_f / total_moves
    
    # High status move ratio = risky
    if status_ratio >= 0.5
      score -= 40  # Very likely to fail
    elsif status_ratio >= 0.25
      score -= 20  # Some risk
    end
    
    # Low HP target is more likely to attack
    if target.hp < target.totalhp * 0.3
      score += 25  # They'll probably try to attack
    end
    
    # Check if target has Protect (might use it)
    has_protect = target.moves.any? { |m| m && AdvancedAI.protect_move?(m.id) }
    if has_protect
      score -= 15  # Risk of Protect
    end
    
    # Target just used an attacking move? More likely to attack again
    if target.battler.lastMoveUsed
      last_move_data = GameData::Move.try_get(target.battler.lastMoveUsed)
      if last_move_data && last_move_data.damaging?
        score += 15  # Pattern suggests attacking
      end
    end
    
    score
  end
  
  # Eject Button / Red Card awareness
  def score_forced_switch_items(move, user, target)
    return 0 unless move.damagingMove?
    score = 0
    
    # Eject Button on target - hitting them forces THEIR switch
    if target.item_id == :EJECTBUTTON
      # This is often good - forces them to switch out
      # But check if we WANT them to switch
      if target.stages[:ATTACK] >= 2 || target.stages[:SPECIAL_ATTACK] >= 2
        score += 30  # Force out a setup sweeper = great!
      else
        score += 10  # Neutral to slightly good
      end
    end
    
    # Red Card on target - hitting them forces OUR switch
    if target.item_id == :REDCARD
      # Check if switching is bad for us
      if user.stages[:ATTACK] >= 2 || user.stages[:SPECIAL_ATTACK] >= 2
        score -= 40  # Don't lose our boosts!
      elsif user.effects[PBEffects::Substitute] && user.effects[PBEffects::Substitute] > 0
        score -= 30  # Don't lose our Sub!
      else
        score -= 10  # Generally don't want forced switch
      end
    end
    
    score
  end
  
  # Estimate incoming damage from opponent's strongest move
  def estimate_incoming_damage(defender, attacker)
    return 0 unless attacker && attacker.moves
    
    max_damage = 0
    attacker.moves.each do |move|
      next unless move && move.power > 0
      
      # Simple damage estimate
      atk = move.physicalMove? ? attacker.attack : attacker.spatk
      defense = move.physicalMove? ? defender.defense : defender.spdef
      defense = [defense, 1].max
      
      type_mod = Effectiveness.calculate(move.type, defender.types[0], defender.types[1])
      type_mult = type_mod.to_f / Effectiveness::NORMAL_EFFECTIVE.to_f
      
      stab = attacker.pbHasType?(move.type) ? 1.5 : 1.0
      
      damage = ((2 * attacker.level / 5.0 + 2) * move.power * atk / defense / 50 + 2)
      damage *= type_mult * stab
      
      max_damage = [max_damage, damage.to_i].max
    end
    
    max_damage
  end
  
  # Item Disruption Moves (Trick, Switcheroo, Knock Off, Thief, Covet)
  def score_item_disruption(move, user, target)
    score = 0
    
    # Trick / Switcheroo - swap items
    if [:TRICK, :SWITCHEROO].include?(move.id)
      # Can't swap if target has Sticky Hold
      return -50 if target.ability_id == :STICKYHOLD
      
      # Can't swap if we have no item to give
      return -30 if !user.item || user.item == :NONE
      
      # Swapping Choice items to non-Choice mons is great
      if [:CHOICEBAND, :CHOICESPECS, :CHOICESCARF].include?(user.item_id)
        score += 50  # Cripple their moveset
        # Even better if they rely on status moves
        status_count = target.moves.count { |m| m && m.statusMove? }
        score += status_count * 15
      end
      
      # Swapping Flame Orb / Toxic Orb
      if [:FLAMEORB, :TOXICORB].include?(user.item_id)
        return -50 if target.status != :NONE  # Already statused
        score += 40  # Inflict status
      end
      
      # Swapping Lagging Tail / Iron Ball to fast mons
      if [:LAGGINGTAIL, :IRONBALL].include?(user.item_id) && target.pbSpeed > 100
        score += 30  # Slow them down
      end
      
      # Getting a good item from target
      good_items = [:LEFTOVERS, :LIFEORB, :FOCUSSASH, :CHOICEBAND, :CHOICESPECS,
                    :CHOICESCARF, :ASSAULTVEST, :ROCKYHELMET, :EVIOLITE]
      if good_items.include?(target.item_id)
        score += 25  # We get a good item
      end
    end
    
    # Knock Off bonus (already handled in damage calc, but add strategic value)
    if move.id == :KNOCKOFF && target.item && target.item != :NONE
      # Removing key items is valuable
      valuable_items = [:LEFTOVERS, :EVIOLITE, :FOCUSSASH, :ASSAULTVEST,
                        :LIFEORB, :CHOICEBAND, :CHOICESPECS, :CHOICESCARF,
                        :ROCKYHELMET, :HEAVYDUTYBOOTS]
      if valuable_items.include?(target.item_id)
        score += 25
      else
        score += 10
      end
    end
    
    # Thief / Covet - steal item
    if [:THIEF, :COVET].include?(move.id)
      return -30 if user.item && user.item != :NONE  # We already have item
      return -30 if !target.item || target.item == :NONE  # Nothing to steal
      score += 20  # Steal their item
    end
    
    # Corrosive Gas - remove item from all adjacent
    if move.id == :CORROSIVEGAS
      score += 15 if target.item && target.item != :NONE
    end
    
    # Incinerate - destroy berry
    if move.id == :INCINERATE
      berry_items = AdvancedAI::Utilities::TYPE_RESIST_BERRIES.keys + 
                    [:SITRUSBERRY, :LUMBERRY, :AGUAVBERRY, :FIGYBERRY, :IAPAPABERRY,
                     :MAGOBERRY, :WIKIBERRY, :LIECHIBERRY, :PETAYABERRY, :SALACBERRY]
      if berry_items.include?(target.item_id)
        score += 20  # Destroy their berry
      end
    end
    
    score
  end
  
  #=============================================================================
  # MOODY PRESSURE - Prioritize attacking Moody Pokemon
  #=============================================================================
  def score_moody_pressure(move, user, target)
    return 0 unless target && target.ability_id == :MOODY
    
    bonus = 0
    
    # Prioritize attacking Moody Pokemon - don't let them accumulate boosts
    if move.damagingMove?
      bonus += 20  # Pressure Moody before they scale
      
      # Even higher if they already have boosts
      total_boosts = 0
      GameData::Stat.each_battle do |stat|
        stage = target.stages[stat.id] rescue 0
        total_boosts += stage if stage > 0
      end
      bonus += total_boosts * 8
    end
    
    # Haze/Clear Smog are excellent vs Moody
    if [:HAZE, :CLEARSMOG].include?(move.id)
      total_boosts = 0
      GameData::Stat.each_battle do |stat|
        stage = target.stages[stat.id] rescue 0
        total_boosts += stage if stage > 0
      end
      bonus += total_boosts * 15
    end
    
    # Taunt prevents Protect stalling for Moody boosts
    if move.id == :TAUNT
      bonus += 15
    end
    
    bonus
  end
  
  #=============================================================================
  # MIRROR HERB - Don't boost if opponent will copy
  #=============================================================================
  def score_setup_vs_mirror_herb(move, user, target)
    return 0 unless AdvancedAI.setup_move?(move.id)
    
    penalty = 0
    
    # Check if any opponent has Mirror Herb
    @battle.allOtherSideBattlers(user.index).each do |opp|
      next unless opp && !opp.fainted?
      
      if opp.item_id == :MIRRORHERB
        # They will copy our stat boosts!
        penalty -= 35  # Significant penalty
        
        # Worse if they're a physical attacker and we're boosting Atk
        if move.function_code.include?("Attack") && opp.attack > opp.spatk
          penalty -= 15
        end
      end
      
      # Also check Opportunist ability
      if opp.ability_id == :OPPORTUNIST
        penalty -= 25
      end
    end
    
    penalty
  end
  
  #=============================================================================
  # LUM BERRY TIMING - Don't status if they have Lum Berry
  #=============================================================================
  def score_status_vs_berry(move, user, target)
    return 0 unless move.statusMove?
    return 0 unless target
    
    # Status-inflicting function codes
    status_codes = ["Poison", "Paralyze", "Burn", "Sleep", "Freeze", "Confuse"]
    is_status_move = status_codes.any? { |code| move.function_code.include?(code) }
    
    # Direct status moves
    status_move_ids = [:WILLOWISP, :THUNDERWAVE, :TOXIC, :POISONPOWDER,
                       :STUNSPORE, :SLEEPPOWDER, :SPORE, :NUZZLE,
                       :GLARE, :HYPNOSIS, :DARKVOID, :YAWN, :CONFUSERAY]
    is_status_move ||= status_move_ids.include?(move.id)
    
    return 0 unless is_status_move
    
    penalty = 0
    
    # Lum Berry cures any status
    if target.item_id == :LUMBERRY
      penalty -= 60  # Status will be immediately cured - waste of turn!
    end
    
    # Chesto Berry specifically for Sleep
    if target.item_id == :CHESTOBERRY
      if move.function_code.include?("Sleep") || 
         [:SPORE, :SLEEPPOWDER, :HYPNOSIS, :DARKVOID, :YAWN].include?(move.id)
        penalty -= 50
      end
    end
    
    # Other status berries
    case target.item_id
    when :RAWSTBERRY
      penalty -= 40 if move.function_code.include?("Burn") || move.id == :WILLOWISP
    when :PECHABERRY
      penalty -= 40 if move.function_code.include?("Poison") || [:TOXIC, :POISONPOWDER].include?(move.id)
    when :CHERIBERRY
      penalty -= 40 if move.function_code.include?("Paralyze") || [:THUNDERWAVE, :STUNSPORE, :NUZZLE, :GLARE].include?(move.id)
    when :ASPEARBERRY
      penalty -= 40 if move.function_code.include?("Freeze")
    when :PERSIMBERRY
      penalty -= 40 if move.function_code.include?("Confuse") || move.id == :CONFUSERAY
    end
    
    # Own Tempo / Oblivious - confusion immunity
    if [:OWNTEMPO, :OBLIVIOUS].include?(target.ability_id)
      if move.function_code.include?("Confuse") || move.id == :CONFUSERAY || move.id == :SWAGGER
        penalty -= 50
      end
    end
    
    penalty
  end
  
  #=============================================================================
  # PROTECT / DETECT SCORING (Stall Strategies)
  #=============================================================================
  def score_protect_utility(move, user, target)
    return 0 unless AdvancedAI.protect_move?(move.id)
    return -100 if user.effects[PBEffects::ProtectRate] > 1  # Don't spam Protect
    
    score = 0
    
    # 1. Self-Recovery / Stat Boost Stall
    # Leftovers / Black Sludge / Ingrain / Aqua Ring / Poison Heal
    passive_recovery = (user.hasActiveItem?(:LEFTOVERS) || user.hasActiveItem?(:BLACKSLUDGE)) ||
                       user.effects[PBEffects::Ingrain] || user.effects[PBEffects::AquaRing] || 
                       (user.hasActiveAbility?(:POISONHEAL) && user.poisoned?) ||
                       (user.hasActiveAbility?([:DRYSKIN, :RAINDISH]) && [:Rain, :HeavyRain].include?(@battle.pbWeather)) ||
                       (user.hasActiveAbility?(:ICEBODY) && [:Hail, :Snow].include?(@battle.pbWeather)) ||
                       user.pbOwnSide.effects[PBEffects::GrassyTerrain] > 0
                       
    if passive_recovery
      hp_percent = user.hp.to_f / user.totalhp
      if hp_percent < 0.9
        score += 40  # Heal up safely
        score += 20 if hp_percent < 0.5  # Critical heal
      end
    end

    # Speed Boost / Moody (Stall for stats)
    if user.hasActiveAbility?(:SPEEDBOOST) || user.hasActiveAbility?(:MOODY)
      score += 50  # Free boost
    end
    
    # Wish active? (Receive healing)
    if user.effects[PBEffects::Wish] > 0
      score += 80  # Protect to receive Wish is standard play
    end

    # 2. Opponent Damage Stall
    # Poison / Burn / Leech Seed / Curse / Salt Cure
    if target
      passive_damage = target.poisoned? || target.burned? || 
                       target.effects[PBEffects::LeechSeed] >= 0 ||
                       target.effects[PBEffects::Curse] ||
                       target.effects[PBEffects::SaltCure]
                       
      if passive_damage
        score += 45  # Let them rot
        score += 20 if target.hp < target.totalhp * 0.25 # Finish them off
      end
      
      # Perish Song stalling
      if target.effects[PBEffects::PerishSong] > 0
        score += 60  # Stall out Perish turns
      end
    end
    
    # 3. Double Battle Scouting (Simple)
    if @battle.pbSideSize(0) > 1 && @battle.turnCount == 0
      score += 20  # Protect turn 1 in doubles is common
    end
    
    return score
  end

  #=============================================================================
  # PRANKSTER BONUS (Priority Status)
  #=============================================================================
  def score_prankster_bonus(move, user)
    return 0 unless user.hasActiveAbility?(:PRANKSTER)
    return 0 unless move.statusMove?
    
    score = 40  # Base bonus for having priority status
    
    # High value Prankster moves
    high_value_moves = [:THUNDERWAVE, :WILLOWISP, :TOXIC, :REFLECT, :LIGHTSCREEN, 
                        :AURORAVEIL, :TAILWIND, :TAUNT, :ENCORE, :DISABLE, :SUBSTITUTE,
                        :SPIKES, :STEALTHROCK, :TOXICSPIKES, :SPORE, :SLEEPPOWDER]
                        
    if high_value_moves.include?(move.id)
      score += 25  # Priority disable/hazards/screens are GODLY
    end
    
    return score
  end
  
  #=============================================================================
  # PIVOT UTILITY (Parting Shot, U-turn, etc.)
  #=============================================================================
  def score_pivot_utility(move, user, target, skill)
    return 0 unless AdvancedAI::PivotMoves::ALL_PIVOTS.include?(move.id)
    
    # Delegate to the specialized Pivot module
    # We add this score to the move's base damage/status score
    return AdvancedAI::PivotMoves.evaluate_pivot(@battle, user, move, target, skill)
  end
  
  #=============================================================================
  # MOVE REPETITION PENALTY (Prevents spamming the same move)
  #=============================================================================
  def score_move_repetition_penalty(move, user)
    score = 0
    
    # Check if this is the last move used
    last_move = user.battler.lastMoveUsed
    return 0 unless last_move  # No previous move
    
    # Penalize using the same move consecutively
    if move.id == last_move
      # Moves that SHOULD be spammed (setup sweepers, Protect stalling)
      spam_allowed = [:PROTECT, :DETECT, :KINGSSHIELD, :SPIKYSHIELD, :BANEFULBUNKER,
                      :OBSTRUCT, :SILKTRAP, :BURNINGBULWARK,  # Protect variants
                      :SWORDSDANCE, :NASTYPLOT, :DRAGONDANCE, :QUIVERDANCE,  # Setup
                      :CALMMIND, :IRONDEFENSE, :AMNESIA, :AGILITY,  # More setup
                      :SHELLSMASH, :GEOMANCY, :VICTORYDANCE]  # Ultra setup
      
      # Also allow spamming moves that CHANGE effect on repeat (Rollout, Fury Cutter)
      escalating_moves = [:ROLLOUT, :ICEBALL, :FURYCUTTER, :ECHOEDVOICE]
      
      return 0 if spam_allowed.include?(move.id)
      return 0 if escalating_moves.include?(move.id)
      
      # Attacking moves: Small penalty (variety is good, but not critical)
      if move.damagingMove?
        score -= 15
        AdvancedAI.log("#{move.name}: -15 for repetition (attacking move)", "MoveSpam")
      end
      
      # Status moves: LARGE penalty (Taunt spam, Thunder Wave spam, etc.)
      if move.statusMove?
        score -= 40
        AdvancedAI.log("#{move.name}: -40 for repetition (status move spam prevention)", "MoveSpam")
      end
    end
    
    # Additional penalty if move was used multiple times recently (via Move Memory)
    if defined?(AdvancedAI::MoveMemory)
      frequency = AdvancedAI::MoveMemory.move_frequency(@battle, user, move.id)
      
      # If used 2+ times, add stacking penalty
      if frequency >= 3
        score -= 20  # Used 3+ times = major spam
        AdvancedAI.log("#{move.name}: -20 for frequency spam (used #{frequency} times)", "MoveSpam")
      elsif frequency >= 2
        score -= 10  # Used 2 times = minor spam
        AdvancedAI.log("#{move.name}: -10 for repeated use (used #{frequency} times)", "MoveSpam")
      end
    end
    
    return score
  end
end

AdvancedAI.log("Move Scorer loaded", "Scorer")
AdvancedAI.log("  - Moody pressure logic", "Scorer")
AdvancedAI.log("  - Mirror Herb awareness", "Scorer")
AdvancedAI.log("  - Lum Berry timing", "Scorer")
